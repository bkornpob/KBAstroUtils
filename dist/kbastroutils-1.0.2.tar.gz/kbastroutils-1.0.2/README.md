# KBAstroUtils

This is a collection of modules for analyses related to astrophysics by Dr. Kornpob Bhirombhakdi. Contact: kbhirombhakdi@stsci.edu

Tasks include:
    - dqmask.py = handle data quality (DQ) arrays

v.1.0.2
    - Fix description of dqmask.py
v.1.0.1
    - Fix import modules in dqmask.py
v.1.0.0
    - Implement dqmask.py